/////////////////////////////////////////////////////////////////////////////
// Name:        wx/generic/fontpickerg.h
// Purpose:     wxGenericFontButton header
// Author:      Francesco Montorsi
// Created:     14/4/2006
// Copyright:   (c) Francesco Montorsi
// Licence:     wxWindows Licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_FONTPICKER_H_
#define _WX_FONTPICKER_H_

#include "wx/button.h"
#include "wx/fontdata.h"

//-----------------------------------------------------------------------------
// wxGenericFontButton: a button which brings up a wxFontDialog
//-----------------------------------------------------------------------------

class WXDLLIMPEXP_CORE wxGenericFontButton : public wxButton,
                                             public wxFontPickerWidgetBase
{
public:
    wxGenericFontButton() = default;
    wxGenericFontButton(wxWindow *parent,
                        wxWindowID id,
                        const wxFont &initial = wxNullFont,
                        const wxPoint& pos = wxDefaultPosition,
                        const wxSize& size = wxDefaultSize,
                        long style = wxFONTBTN_DEFAULT_STYLE,
                        const wxValidator& validator = wxDefaultValidator,
                        const wxString& name = wxASCII_STR(wxFontPickerWidgetNameStr))
    {
        Create(parent, id, initial, pos, size, style, validator, name);
    }

    virtual wxColour GetSelectedColour() const override
        { return m_data.GetColour(); }

    virtual void SetSelectedColour(const wxColour &colour) override
        { m_data.SetColour(colour); UpdateFont(); }

    virtual ~wxGenericFontButton() = default;


public:     // API extensions specific for wxGenericFontButton

    // user can override this to init font data in a different way
    virtual void InitFontData();

    // returns the font data shown in wxFontDialog
    wxFontData *GetFontData() { return &m_data; }


public:

    bool Create(wxWindow *parent,
                wxWindowID id,
                const wxFont &initial = *wxNORMAL_FONT,
                const wxPoint& pos = wxDefaultPosition,
                const wxSize& size = wxDefaultSize,
                long style = wxFONTBTN_DEFAULT_STYLE,
                const wxValidator& validator = wxDefaultValidator,
                const wxString& name = wxASCII_STR(wxFontPickerWidgetNameStr));

    void OnButtonClick(wxCommandEvent &);


protected:

    void UpdateFont() override;

    wxFontData m_data;

private:
    void OnSysColourChanged(wxSysColourChangedEvent& event);

    // Set to true if the user selected a text colour in the font dialog, in
    // which case we use this colour and not update to the default one when the
    // system colours change.
    bool m_useUserColour = false;

    wxDECLARE_DYNAMIC_CLASS(wxGenericFontButton);
};


#endif // _WX_FONTPICKER_H_
